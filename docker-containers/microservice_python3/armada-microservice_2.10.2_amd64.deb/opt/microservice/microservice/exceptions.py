class ArmadaApiServiceNotFound(Exception):
    pass
